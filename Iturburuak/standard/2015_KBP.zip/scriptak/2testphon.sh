#!/bin/bash

#######
# jarraitutako urratsen laburpena
# PARAMETROAK:
# $1: test-eko fitxategia
# $2: phonetisaurus-entzat katalogoa
# $3: eskatutako erantzun kopurua
# $4: erantzunak iragazteko automata


# testeko zerrendan hitz bera jarraian ageri bada, tratatu (ccc katea sartzen da tartean)
../scriptak/filtrobikoiz_aurretik.pl $1 >$1.berria

# phonetisaurus-i galdetu $4 erantzun eman ditzan
echo "ESKATUTAKO ERANTZUNAK: $3"
phonetisaurus-g2p --model=$2/$2.fst --input=$1.berria --isfile --words --nbest=$3  --beam=5000 >$1.phon2

#erantzuna egokitu
cut -f3 $1.phon2 >tmp
../scriptak/hitza_elkartu.pl tmp >tmp2

cut -f1,2 $1.phon2 >tmp
paste tmp tmp2 >$1.phon2
 rm tmp*

# begiratu phonetisaurus-ek itzulitakoa onartzen duen automatak
cut $1.phon2 -f3 | flookup $4 >tmp

# aurreko fitxategiko lerro zuriak kendu eta automataren erantzuna soilik utzi
grep . tmp >tmp2

# $1 fitxategiko lehen zutabeak (testeko hitzak eta pisua)
cut -f1,2 $1.phon2 >tmp3

# elkartzen ditugu formatu egokiko fitxategia eta analisiaren emaitza duena
paste tmp3 tmp2 >tmp4

# erantzunak kendu baino lehen "ccc" sarrerak tratatu behar dira. horiek sartu ditugu hasieran hitz bera
# jarraian ageri bada
../scriptak/filtrobikoiz_atzetik.pl tmp4 >tmp5

# onartzen ez direnak kendu
grep -v "+?" tmp5 >tmp6

# pisuaren arabera, erantzuna aukeratzen dugu
../scriptak/aukeratuprob.pl tmp6 >tmp7

# kendu ccc sarrerak eta pisua azken erantzuna emateko
grep -v ccc tmp7 | cut -f1,3 >$1.phon3

../scriptak/sortu_txuria.pl $1 >txuria

../scriptak/konbiberria.pl $1 $1.phon3 txuria txuria txuria >$1.phon4

rm tmp*
